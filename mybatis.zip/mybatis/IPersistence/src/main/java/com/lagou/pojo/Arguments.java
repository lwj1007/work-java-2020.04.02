package com.lagou.pojo;

public class Arguments {
    public static String SELECT="select";
    public static String ADD="insert";
    public static String DELETE="delete";
    public static String UPDATE="update";
}
